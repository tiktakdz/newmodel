export default function Home() {
  return (
    <div className="space-y-6">
      <h1 className="text-4xl font-bold">Bienvenue sur NEWMODEL</h1>
      <p className="text-neutral-400">Blog, forum et annuaire de prestataires.</p>
    </div>
  );
}
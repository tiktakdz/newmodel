import "./globals.css";
import Navbar from "@/components/Navbar";

export const metadata = { title: "NEWMODEL", description: "Blog / Forum / Prestataires" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="bg-neutral-950 text-neutral-100">
        <Navbar />
        <main className="max-w-5xl mx-auto p-4">{children}</main>
      </body>
    </html>
  );
}
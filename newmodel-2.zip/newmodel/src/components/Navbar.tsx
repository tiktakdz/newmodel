import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="border-b border-neutral-800 px-4 py-3 flex gap-4 text-sm">
      <Link href="/" className="font-bold">NEWMODEL</Link>
      <Link href="/forum">Forum</Link>
      <Link href="/blog">Blog</Link>
      <Link href="/prestataires">Prestataires</Link>
      <Link href="/auth/login" className="ml-auto">Connexion</Link>
      <Link href="/auth/register">Inscription</Link>
    </nav>
  );
}